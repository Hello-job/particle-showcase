import { DEEPSEEK_SHAPE } from "./custom-shapes.js";
import { DEEPSEEK_TITLECASE_WORDMARK_SHAPE } from "./deepseek-titlecase.js";
import { KIMI_SHAPE, KIMI_WORDMARK_SHAPE, GLM_WORDMARK_SHAPE, ZAI_SHAPE } from "./brand-shapes.js";

// Extracted from the public OpenAI Astra source, 28nbglk5oli9p.js.
// Shader, geometry and motion math are preserved; see README.md for provenance.
export default (e) => {
  "use strict";
  let t =
      "M9.60978 17.0223C9.24308 17.739 8.76808 18.189 8.18478 18.3723C7.60148 18.564 7.03478 18.4931 6.48478 18.1598C5.93478 17.8348 5.53061 17.314 5.27228 16.5973L0.672282 3.68478C0.497282 3.19312 0.455612 2.72645 0.547282 2.28478C0.638952 1.83478 0.838952 1.45561 1.14728 1.14728C1.45561 0.838948 1.83478 0.638949 2.28478 0.547279C2.73478 0.455619 3.20561 0.497279 3.69728 0.672279L16.6098 5.27228C17.3265 5.53062 17.8473 5.93478 18.1723 6.48478C18.5056 7.02648 18.5765 7.58898 18.3848 8.17228C18.2015 8.75558 17.7515 9.23058 17.0348 9.59728L12.1098 12.1098L9.60978 17.0223Z",
    a = [
      "M1025.52 167.475C960.586 89.5754 862.821 40 753.477 40C557.968 40 399.477 198.491 399.477 394V737.278C399.477 757.119 409.975 775.478 427.074 785.541L851.477 1035.3",
      "M1465.07 608.95C1500.07 513.764 1494.12 404.309 1439.45 309.614C1341.69 140.298 1125.19 82.2866 955.872 180.041L658.585 351.68C641.402 361.6 630.752 379.872 630.587 399.712L626.49 892.135",
      "M1302.52 1210.35C1402.45 1193.06 1494.27 1133.18 1548.94 1038.49C1646.69 869.17 1588.68 652.667 1419.36 554.912L1122.08 383.273C1104.89 373.353 1083.75 373.265 1066.48 383.042L637.982 625.706",
      "M700.415 1370.27C765.351 1448.17 863.116 1497.74 972.461 1497.74C1167.97 1497.74 1326.46 1339.25 1326.46 1143.74V800.466C1326.46 780.625 1315.96 762.266 1298.86 752.203L874.461 502.444",
      "M260.866 928.794C225.871 1023.98 231.82 1133.44 286.492 1228.13C384.247 1397.45 600.75 1455.46 770.065 1357.7L1067.35 1186.06C1084.54 1176.14 1095.19 1157.87 1095.35 1138.03L1099.45 645.61",
      "M423.42 327.396C323.488 344.682 231.672 404.562 177 499.257C79.2456 668.573 137.257 885.076 306.573 982.83L603.861 1154.47C621.043 1164.39 642.192 1164.48 659.456 1154.7L1087.96 912.037",
    ];
  e.s([
    "ASTRA_CURSOR_PATH",
    0,
    t,
    "ASTRA_OPENAI_KNOT_PATHS",
    0,
    a,
    "ASTRA_SHAPE_SVGS",
    0,
    {
      cursor: { height: 19, paths: [t], width: 19 },
      deepseek: DEEPSEEK_SHAPE,
      "deepseek-wordmark": DEEPSEEK_TITLECASE_WORDMARK_SHAPE,
      kimi: { ...KIMI_SHAPE, filled: true, label: "Kimi symbol" },
      "kimi-wordmark": { ...KIMI_WORDMARK_SHAPE, filled: true, label: "Kimi wordmark" },
      "glm-wordmark": { ...GLM_WORDMARK_SHAPE, filled: true, label: "GLM wordmark" },
      zai: { ...ZAI_SHAPE, filled: true, label: "Z.ai symbol" },
      "openai-knot": { height: 1538, paths: a, width: 1726 },
    },
    "resolveAstraPathShape",
    0,
    function (e) {
      if (e === "deepseek") return "deepseek";
      if (e === "deepseek-wordmark") return "deepseek-wordmark";
      if (["kimi", "kimi-wordmark", "glm-wordmark", "zai"].includes(e)) return e;
      return "cursor" === e
        ? "cursor"
        : "openai-knot" === e || "blossom" === e
          ? "openai-knot"
          : null;
    },
  ]);
};
